
public class TestBankQ2 {

	public static void main(String[] args) {
		String [] bankArgs = {"q2.txt"};
		Banker.main(bankArgs);
	}

}
